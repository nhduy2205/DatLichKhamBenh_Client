import HomePage from "./pages";

export default function Home() {
  return (
   <HomePage/>
  )
}
